import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    HeaderComponent,
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss',
})
export class ProfileComponent {
  editing = signal(false);
  saving = signal(false);

  user = this.auth.currentUser();

  form = this.fb.group({
    fullName: [this.user?.fullName || '', [Validators.required, Validators.minLength(3)]],
    email: [{ value: this.user?.email || '', disabled: true }],
    phone: [this.user?.phone || '', [Validators.pattern(/^[0-9]{10}$/)]],
    state: [this.user?.state || ''],
  });

  constructor(public auth: AuthService, private fb: FormBuilder, private snackBar: MatSnackBar) {}

  toggleEdit(): void {
    this.editing.set(!this.editing());
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    // Mock save — replace with HttpClient PUT to /api/users/:id when backend is ready
    setTimeout(() => {
      const raw = this.form.getRawValue();
      const updated = {
        ...this.auth.currentUser()!,
        fullName: raw.fullName!,
        phone: raw.phone || undefined,
        state: raw.state || undefined,
      };
      this.auth.currentUser.set(updated);
      localStorage.setItem('policygpt_user', JSON.stringify(updated));
      this.saving.set(false);
      this.editing.set(false);
      this.snackBar.open('Profile updated successfully.', 'Close', { duration: 3000 });
    }, 600);
  }
}
