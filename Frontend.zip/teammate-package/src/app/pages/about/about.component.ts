import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderComponent } from '../../shared/components/header/header.component';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, MatIconModule, HeaderComponent],
  templateUrl: './about.component.html',
  styleUrl: './about.component.scss',
})
export class AboutComponent {
  values = [
    { icon: 'visibility', title: 'Transparency', desc: 'Every policy and scheme is sourced from official government notifications and kept up to date.' },
    { icon: 'diversity_3', title: 'Inclusivity', desc: 'Built for citizens, officials, researchers, and organizations alike — no matter their digital literacy.' },
    { icon: 'bolt', title: 'Simplicity', desc: 'Complex eligibility rules and application steps, simplified into plain language.' },
    { icon: 'security', title: 'Trust', desc: 'Role-based access and secure authentication protect every user\'s data.' },
  ];

  roles = [
    { role: 'Administrator', desc: 'Manage system, users, and policy approvals.' },
    { role: 'Government Official', desc: 'Upload and update policies, schemes, and notifications.' },
    { role: 'Citizen', desc: 'Search policies, check eligibility, and track applications.' },
    { role: 'Researcher', desc: 'Analyze policy data and generate structured reports.' },
    { role: 'Organization', desc: 'Access relevant policies, schemes, and department reports.' },
    { role: 'Guest User', desc: 'View publicly available policy and scheme information.' },
  ];
}
