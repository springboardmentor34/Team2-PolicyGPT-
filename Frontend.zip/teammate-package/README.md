# Your Part — About / Contact / Profile + Sidebar / Header / Loader / NotFound

This folder mirrors the exact path structure inside `policygpt-frontend/`.
Once you clone the repo, copy the `src` folder here on top of your local
copy (paths match exactly, so it's just a drag-and-drop merge) — then commit
and push from a new branch so it shows up as your contribution on GitHub.

```bash
git clone https://github.com/<owner>/policygpt-frontend.git
cd policygpt-frontend
git checkout -b feature/about-contact-profile-sidebar

# copy the contents of this package's src/ folder into your local src/ folder

git add .
git commit -m "Add About, Contact, Profile pages and Sidebar/Header/Loader/NotFound components"
git push -u origin feature/about-contact-profile-sidebar
```

Then open a Pull Request on GitHub against `main` and ask your teammate to
review/merge it.

## What's in here
- `src/app/pages/about/` — Platform mission, values, and user-role descriptions
- `src/app/pages/contact/` — Contact form with validation
- `src/app/pages/profile/` — View/edit logged-in user details
- `src/app/shared/components/sidebar/` — Side nav panel for dashboard layouts
- `src/app/shared/components/header/` — Reusable page title/subtitle header
- `src/app/shared/components/loader/` — Loading spinner
- `src/app/shared/components/not-found/` — 404 page
