import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HeaderComponent } from '../../shared/components/header/header.component';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    HeaderComponent,
  ],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss',
})
export class ContactComponent {
  submitting = signal(false);
  submitted = signal(false);

  form = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    topic: ['General Inquiry', Validators.required],
    message: ['', [Validators.required, Validators.minLength(10)]],
  });

  topics = ['General Inquiry', 'Report an Issue', 'Policy Correction', 'Partnership', 'Feedback'];

  contactInfo = [
    { icon: 'mail', label: 'support@policygpt.gov.in' },
    { icon: 'call', label: '1800-11-2345 (Toll Free)' },
    { icon: 'place', label: 'Ministry of Electronics & IT, New Delhi' },
  ];

  constructor(private fb: FormBuilder, private snackBar: MatSnackBar) {}

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    // Mock submission — replace with HttpClient POST to /api/feedback later
    setTimeout(() => {
      this.submitting.set(false);
      this.submitted.set(true);
      this.snackBar.open('Message sent! Our team will respond within 2 business days.', 'Close', {
        duration: 4000,
      });
      this.form.reset({ topic: 'General Inquiry' });
    }, 700);
  }
}
